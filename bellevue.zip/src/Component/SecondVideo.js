import React from 'react'

function SecondVideo() {
  return (
    <div>SecondVideo</div>
  )
}

export default SecondVideo