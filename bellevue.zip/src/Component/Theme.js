import React from 'react'

function Theme() {
  return (
    <div>
        <div className='theme_26_2022'>
             <div className='container'>
                    <div className='row'>
                      <div col-md-8>
                        <div className='theme_btn'>

                        <h3>Does this look like fun? Check out our accomodations.</h3>
                        </div>
                      </div>
                      <div col-md-4>
                      <div className='theme_btn'>

                        <button className='mt-2'>Download Theme</button>
                      </div>
                      </div>
                    </div>
             </div>
        </div>
    </div>
  )
}

export default Theme