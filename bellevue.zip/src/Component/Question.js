import React from 'react'

function Question() {
  return (
    <div>
      <div className='question'>
        <h1 className='text-center mb-5'>Question?</h1>
        <div className='container'>
          <div className="row">
            <div className='col-md-3'>
              <input type='text' className='inputArea' placeholder='Name' />
              </div>
            <div className='col-md-3'>
              <input type='text' className='inputArea' placeholder='Email Address' />
              </div>
            <div className='col-md-3'>
              <input type='text' className='inputArea' placeholder='Question/Comments' />
              </div>
            <div className='col-md-3'>
              <button>Send</button>
              </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Question;