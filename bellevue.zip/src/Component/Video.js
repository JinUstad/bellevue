import React from 'react'
import video from '../Assests/videotour.jpg'
function Video() {

    const playVideo = () => {
        document.getElementById('iframeVideo').style.display = "block";
        document.getElementById('btnClose').style.display = "block";
    }
    const closeBtn = () =>{
        document.getElementById('iframeVideo').style.display = "none";
        document.getElementById('btnClose').style.display = "none";
    }

    return (
        <div>
            <div className='videoTours' >
                <img src={video} />
                <div className='imgVideo' >
                    <h2 id='btnClose' onClick={closeBtn}>X</h2>

                    <h1>Video Tour</h1>
                    <i className='fa fa-play' onClick={playVideo} ></i>
                </div>

                <div className='video_container ' id='iframeVideo' style={{ display: 'none' }}>
                    <iframe className='videoSec' width='853' height='395'
                        src="https://www.youtube.com/embed/tgbNymZ7vqY">
                    </iframe>


                </div>
            </div>
        </div>
    )
}

export default Video